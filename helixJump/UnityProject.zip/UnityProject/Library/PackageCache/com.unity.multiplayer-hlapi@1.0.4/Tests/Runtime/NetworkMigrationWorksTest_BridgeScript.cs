﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NetworkMigrationWorksTest_BridgeScript : MonoBehaviour
{
    public const string bridgeGameObjectName = "NetworkMigrationWorksTest_BridgeScriptGO";

    public GameObject playerPrefab;
}
